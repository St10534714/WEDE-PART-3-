# Lovemreiks Kitchen – Part 3

## Project overview
A responsive multi-page website for Lovemreiks Kitchen. The project builds on the Part 2 styling and page structure.

## Part 3 features implemented
- Added `JS/script.js` for client-side interactivity and DOM manipulation.
- Added a search field on Services to filter menu/service cards as the user types.
- Added a gallery lightbox: selecting a photograph opens a larger dialog; close button, backdrop click and Escape (native dialog) close it.
- Added a collapsible FAQ using the native HTML `details`/`summary` element.
- Added an OpenStreetMap embed centered on Musina town. It is an area map only; the exact Stand No. 42 pin has not been verified.
- Added `enquiry.html` with an enquiry form for food orders, catering, menu/prices, availability and volunteering/sponsorship.
- Added a separate contact form to `contact.html` for general messages.
- Added required fields, email validation, phone pattern validation and minimum text lengths. JavaScript validates before preparing a `mailto:` email.
- Added page-specific descriptions and keyword metadata, descriptive titles, semantic headings, image alt text and internal links.
- Added `robots.txt` and `sitemap.xml`. Replace `https://YOUR-DOMAIN.example` with the actual deployed domain before publishing.
- Added keyboard focus styles and reduced-motion support.

## Important form limitation
The forms validate in the browser and open the visitor's email application with a pre-filled message addressed to LovemreiksKitchen3@gmail.com. The visitor must press Send. This static website does not have a server/database and therefore does not transmit or store form submissions automatically. For automatic online submissions, connect a form backend such as Netlify Forms after deployment.

## Part 2 feedback changes
The supplied Part 2 folder did not include lecturer feedback or a marking sheet with individual corrections. The original Part 2 improvements have been retained. No specific lecturer feedback has been claimed as completed. General improvements and Part 3 additions are recorded below.

## Changelog
### Part 2 → Part 3
**Date:** 2026-11-02
1. **SEO metadata:** Replaced generic page descriptions with page-specific descriptions and added relevant keywords and author metadata.
2. **Internal navigation:** Added an Enquiry link to the main navigation and created a dedicated `enquiry.html` page.
3. **Service search:** Added a search input and JavaScript filtering so visitors can find menu items and services without reloading the page.
4. **Gallery lightbox:** Made gallery images clickable. JavaScript copies the selected image into an accessible HTML dialog for a larger view.
5. **FAQ interaction:** Added a collapsible FAQ section using native HTML disclosure functionality.
6. **Contact form:** Added name, email, phone, message type and message fields with browser and JavaScript validation.
7. **Enquiry form:** Added fields for contact details, enquiry category, preferred date and enquiry details. Valid submissions prepare an email addressed to the business.
8. **Map:** Added an OpenStreetMap embed centered on Musina. The map is not represented as an exact location for Stand No. 42.
9. **Technical SEO:** Added `robots.txt` and `sitemap.xml`; deployment placeholders must be replaced with the real site URL.
10. **Accessibility and performance:** Added visible keyboard focus styles, lazy loading for the map and reduced-motion support.

### Part 1 → Part 2 (retained history)
- Added external responsive CSS, consistent burgundy/cream/gold colours, Flexbox and Grid layouts, responsive breakpoints, responsive video/images, viewport metadata, alt text and navigation labelling.

## Testing checklist
- Open `home.html` and use every navigation link, including Enquiry.
- On Services, search for terms such as “pap”, “cakes” and “breakfast”; unrelated cards should hide.
- On Gallery, click each image, then close using the close button, outside click or Escape.
- Submit each form empty, with an invalid email and with a valid set of details. Invalid values should be rejected; valid details should open a pre-filled email (press Send manually).
- Check the Musina map loads when internet access is available.
- Test desktop, tablet and mobile widths (1440px, 768px and 375px).
- Check all image/video paths and page links after extracting the folder.

## GitHub and deployment instructions
1. Open the project folder in Visual Studio Code.
2. Open Terminal → New Terminal. Run `git init` if it is not already a Git repository.
3. Run `git add .` then `git commit -m "Complete Part 3 functionality and SEO"`.
4. Create/open your GitHub repository, connect it using the repository URL supplied by GitHub, then run `git remote add origin YOUR-REPOSITORY-URL` and `git push -u origin main` (if your branch is named `main`).
5. For GitHub Pages, open repository Settings → Pages, choose the deployment branch/folder and save. Alternatively, drag the project folder into Netlify's manual deploy area.
6. Copy the published website URL. Replace `YOUR-DOMAIN.example` in `robots.txt` and `sitemap.xml` with that URL, commit and push the updates.
7. Submit the GitHub repository URL and deployed website URL on the Learning Management System.

## References
- Google Search Central (n.d.) SEO Starter Guide. Available at: https://developers.google.com/search/docs/fundamentals/seo-starter-guide (Accessed: 2 November 2026).
- MDN Web Docs (n.d.) HTML forms: validation. Available at: https://developer.mozilla.org/en-US/docs/Learn_web_development/Extensions/Forms/Form_validation (Accessed: 2 November 2026).
- MDN Web Docs (n.d.) HTMLDialogElement. Available at: https://developer.mozilla.org/en-US/docs/Web/API/HTMLDialogElement (Accessed: 2 November 2026).
- OpenStreetMap (n.d.) OpenStreetMap. Available at: https://www.openstreetmap.org/ (Accessed: 2 November 2026).

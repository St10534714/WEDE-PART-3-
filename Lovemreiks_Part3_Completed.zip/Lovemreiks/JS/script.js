document.addEventListener('DOMContentLoaded', () => {
  // Filter service/menu cards as the visitor types.
  const search = document.querySelector('#serviceSearch');
  if (search) search.addEventListener('input', () => {
    const term = search.value.trim().toLowerCase();
    document.querySelectorAll('#servicesGrid > article').forEach(card => {
      card.hidden = !card.textContent.toLowerCase().includes(term);
    });
  });

  // Accessible image lightbox.
  const dialog = document.querySelector('#lightbox');
  const largeImage = document.querySelector('#lightboxImage');
  document.querySelectorAll('.lightbox-trigger img').forEach(img => img.closest('button').addEventListener('click', () => {
    if (!dialog || !largeImage) return;
    largeImage.src = img.src; largeImage.alt = img.alt;
    if (typeof dialog.showModal === 'function') dialog.showModal();
  }));
  document.querySelector('#closeLightbox')?.addEventListener('click', () => dialog.close());
  dialog?.addEventListener('click', event => { if (event.target === dialog) dialog.close(); });

  // Validate forms, then open a pre-addressed email. No details are sent to a server.
  document.querySelectorAll('form[data-form-type]').forEach(form => form.addEventListener('submit', event => {
    event.preventDefault();
    const feedback = form.querySelector('.form-feedback');
    if (!form.checkValidity()) { form.reportValidity(); if (feedback) feedback.textContent = 'Please correct the highlighted fields.'; return; }
    const data = new FormData(form);
    const type = form.dataset.formType === 'enquiry' ? 'Website enquiry' : 'Website contact message';
    const body = [...data.entries()].map(([key, value]) => `${key}: ${value}`).join('\n');
    if (feedback) feedback.textContent = 'Your details are valid. Your email application should open; review the message and press Send.';
    window.location.href = `mailto:LovemreiksKitchen3@gmail.com?subject=${encodeURIComponent(type)}&body=${encodeURIComponent(body)}`;
  }));

  // OpenStreetMap embed centered on Musina town, not an asserted exact stand location.
  const map = document.querySelector('#map');
  if (map) {
    const frame = document.createElement('iframe');
    frame.title = 'OpenStreetMap showing Musina, Limpopo';
    frame.loading = 'lazy'; frame.referrerPolicy = 'no-referrer-when-downgrade';
    frame.src = 'https://www.openstreetmap.org/export/embed.html?bbox=29.98%2C-22.38%2C30.05%2C-22.30&layer=mapnik&marker=-22.34%2C30.02';
    frame.style.cssText = 'width:100%;height:100%;border:0'; map.appendChild(frame);
  }
});